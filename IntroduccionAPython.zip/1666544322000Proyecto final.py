archivo = open('Registro.txt', 'a')

#Bienvenida al programa
registro= {}
print('Bienvenid@ a tu programa evaluador de conocimientos')

seguir = 'si'
while seguir in ['si','SI','Si','sI','Yes','yes','Si quiero']:
    nombres= []
    opcion= input('¿Que accion desea relizar? \n A) Comenzar prueba de conocimientos \n B) Eliminar del registro del sistema \n C) Ver del registro del sistema\n D) Salir\n --- ')
    if opcion in ['a', 'A']:
        print('********************************************')
        print('Por favor registrate en el sistema para comenzar la prueba')
        persona= input('Ingresa el nombre del siguiente alumno: ')
        nombres.append(persona)
        print(nombres)
        
        for persona in nombres:
            edad= int(input('Ingresa la edad de ' + persona + ' : '))
        
            print('*************************************************************')
            español= []
            print('Responde a las siguientes preguntas relacionadas a Español')
            respuesta1= int(input('Son textos breves, ingeniosos en prosa o verso donde los vocablos riman, contienen una enseñanza, consejo o moraleja:\n 1 Moraleja \n 2 Refrán \n 3 Dicho \n 4 Leyenda\n Tu respuesta (Inserta el número)--->'))
            if respuesta1 == 2:
                español.append('1')
                print('Por favor continue con su evaluacion')
            else:
                print('Por favor continue con su evaluacion')    
            respuesta2= int(input('Recurso literario que hace alusión a la repetición de sonidos al final de los versos:\n 1 Analogía \n 2 Metáfora \n 3 Antítesis \n 4 Rima\n Tu respuesta (Inserta el número)--->'))
            if respuesta2 == 4:
                español.append('1')
                print('Por favor continue con su evaluacion')
            else:
                print('Por favor continue con su evaluacion')    
            respuesta3= int(input('Mensaje implícito del siguiente refrán: "Al río revuelto, ganancia de pescadores":\n 1 Que entre más peces en el agua eres ganador \n 2 Si el río est´á revuelto, la pesca es más abundante \n 3 Entre más marea, mejor momento de pesca \n 4 Donde hay conflictos cualquiera se puede aprovechar de ello\n Tu respuesta (Inserta el número)--->'))
            if respuesta3 == 4:
                español.append('1')
                print('Por favor continue con su evaluacion')
            else:
                print('Por favor continue con su evaluacion')  
            respuesta4= int(input('Son palabras que modifican al sustantivo y brindan características o propiedades de él:\n 1 Adjetivos \n 2 Verbos \n 3 Artículos \n 4 Adverbios\n Tu respuesta (Inserta el número)--->'))
            if respuesta4 == 1:
                español.append('1')
                print('Por favor continue con su evaluacion')
            else:
                print('Son palabras que complementan al verbo, un adjetivo e incluso oraciones. Indican circunstancias del verbo (modo, lugar, tiempo, cantidad, afirmación o duda):\n 1 Sustantivo \n 2 Predicado \n 3 Adverbio \n 4 Adjetivo\n Tu respuesta (Inserta el número)--->')
            respuesta5= int(input('1+1: '))
            if respuesta5 == 3:
                español.append('1')
                print('Por favor continue con su evaluacion')
            else:
                print('Por favor continue con su evaluacion')
            respuesta6= int(input('Textos que contienen explicaciones o pasos para hacer funcionar algo, se acompaña de dibujos, ilustraciones, esquemas o procesos. Da características de algún objeto, animal, persona o cosa:\n 1 Mapa Mental \n 2 Descripción \n 3 Resumen \n 4 Mapa Conceptual\n Tu respuesta (Inserta el número)--->'))
            if respuesta6 == 2:
                español.append('1')
                print('Por favor continue con su evaluacion')
            else:
                print('Por favor continue con su evaluacion')
            respuesta7= int(input('Indica una breve pausa en la oración y separa elementos en las numeraciones:\n 1 Punto \n 2 Punto y Coma \n 3 Coma \n 4 Punto y Seguido\n Tu respuesta (Inserta el número)--->'))
            if respuesta7 == 3:
                español.append('1')
                print('Por favor continue con su evaluacion')
            else:
                print('Por favor continue con su evaluacion')
            respuesta8= int(input('Se usa para separar los elementos de una enumeración cuando algunos de ellos llevan coma y cuando se enlazan dos oraciones largas:\n 1 Punto \n 2 Punto y Coma \n 3 Coma \n 4 Punto y Seguido\n Tu respuesta (Inserta el número)--->'))
            if respuesta8 == 2:
                español.append('1')
                print('Por favor continue con su evaluacion')
            else:
                print('Por favor continue con su evaluacion')
            print('Los panecillos de Pasas\nUna vez, un padre le dijo a su hijo:\n- Por favor, vete deprisa al correo y tráeme treinta sellos\nY la madre añadió:\n- Ve a la panadería y compra tres panecillos de pasas\nEl niño salió corriendo con el dinero.\nComo el correo estaba cerca, se quedó un ratito a jugar en la calle con unos niños\nLuego fue corriendo al correo y compró tres sellos\nDespués fue a la panadería y compró treinta panecillos de pasas.\nAl llegar a casa, el padre se echó a reír y dijo:\n- Bueno, pues ahora pegaré panecillos de pasas en mis cartas.\nY la madre también se echó a reír.\nPrepararon la merienda y comieron tantos panecillos de pasas que tuvieron dolor de tripa.\n- Úrsula Wolfel')
            respuesta9= int(input('De la lectura anterior, responde: ¿Qué les pasa por comer tantos panecillos?\n 1 Dolor de Tripa \n 2 Dolor de garganta \n 3 Dolor de cabeza \n 4 Dolor de Muela\n Tu respuesta (Inserta el número)--->'))
            if respuesta9 == 1:
                español.append('1')
                print('Por favor continue con su evaluacion')
            else:
                print('Por favor continue con su evaluacion')
            respuesta10= int(input(('De la lectura anterior, responde: ¿Qué hizo el padre cuando el niño llegó a casa?\n 1 Lo regañó \n 2 Le dijo que regresara a comprar más panecillos \n 3 Se echó a reír \n 4 Se puso a llorar\n Tu respuesta (Inserta el número)--->')))
            if respuesta10 == 3:
                español.append('1')
                print('Por favor continue con su evaluacion')
            else:
                print('Por favor continue con su evaluacion')          
            print('Tu promedio en español es de ' + str(len(español)))
            promedioE= float(len(español))

            print('*************************************************************')
            mate= []
            print('Responde a las siguientes preguntas relacionadas a mate')
            MR1= int(input('1. Cuál es la representación gráfica del número nueve mil treinta y seis.'))
            if MR1 == 9036:
                mate.append('1')
                print('Por favor continue con su evaluacion')
            else:
                print('Por favor continue con su evaluacion')    
            MR2= int(input('2. A cuántas unidades equivale 10 decenas de millar.'))
            if MR2 == 100000:
                mate.append('1')
                print('Por favor continue con su evaluacion')
            else:
                print('Por favor continue con su evaluacion')    
            MR3= int(input('3. Aproxima el número 58 a la decena.'))
            if MR3 == 60:
                mate.append('1')
                print('Por favor continue con su evaluacion')
            else:
                print('Por favor continue con su evaluacion')  
            MR4= int(input('4. Escribe el número ordinal trigésimo quinto en cifras.'))
            if MR4 == 35:
                mate.append('1')
                print('Por favor continue con su evaluacion')
            else:
                print('Por favor continue con su evaluacion')
            MR5= int(input('5. Qué cantidad expresa el número romano V.'))
            if MR5 == 5:
                mate.append('1')
                print('Por favor continue con su evaluacion')
            else:
                print('Por favor continue con su evaluacion')
            MR6= int(input('6. Qué número resulta si divides 56 entre 7.'))
            if MR6 == 8:
                mate.append('1')
                print('Por favor continue con su evaluacion')
            else:
                print('Por favor continue con su evaluacion')
            MR7= int(input('7. Cuál es el número anterior a 1000.'))
            if MR7 == 999:
                mate.append('1')
                print('Por favor continue con su evaluacion')
            else:
                print('Por favor continue con su evaluacion')
            MR8= int(input('8 Cómo escribirías en cifras seiscientos veinticinco mil doscientos dos.'))
            if MR8 == 625202:
                mate.append('1')
                print('Por favor continue con su evaluacion')
            else:
                print('Por favor continue con su evaluacion')
            MR9= int(input('9. Si en una carrera vas tres puestos por detrás del vigésimo segundo, ¿en qué puesto vas?'))
            if MR9 == 19:
                mate.append('1')
                print('Por favor continue con su evaluacion')
            else:
                print('Por favor continue con su evaluacion')
            MR10= int(input('10. Para calcular cuánto es un tercio de 3996, ¿qué tienes que hacer?'))
            if MR10 == 'Dividir':
                mate.append('1')
                print('Por favor continue con su evaluacion')
            else:
                print('Por favor continue con su evaluacion')          
            print('Tu promedio en mate es de ' + str(len(mate)))
            promedioM= float(len(mate))

            print('*************************************************************')
            ciencias= []
            print('Responde a las siguientes preguntas relacionadas a ciencias')
            MC1= int(input('Proceso continuo del paso de alimentos de un ser a otro al comer y ser comido:\n 1 Cadena Alimentaria \n 2 Ecosistema \n 3 Digestión \n 4 Cena de Amigos\n Tu respuesta (Inserta el número)--->'))
            if MC1 == 1:
                ciencias.append('1')
                print('Por favor continue con su evaluacion')
            else:
                print('Por favor continue con su evaluacion')    
            MC2= int(input('Según la cadena alimentaria, ¿qué animales se alimentan de plantas?\n 1 Omnívoros \n 2 Carnívoros \n 3 Herbívoros\n Tu respuesta (Inserta el número)--->'))
            if MC2 == 3:
                ciencias.append('1')
                print('Por favor continue con su evaluacion')
            else:
                print('Por favor continue con su evaluacion')    
            MC3= int(input('Los hongos y bacterias son organismos:\n 1 Productores \n 2 Consumidores \n 3 Descomponedores \n 4 Ninguna de las anteriores\n Tu respuesta (Inserta el número)--->'))
            if MC3 == 4:
                ciencias.append('1')
                print('Por favor continue con su evaluacion')
            else:
                print('Por favor continue con su evaluacion')  
            MC4= int(input('¿Cuáles son los tres estados de la materia?\n 1 Líquido, Sólido y Gelatinoso \n 2 Líquido, Gaseoso y Sólido \n 3 Viscoso, Gaseoso y Sólido \n 4 Sólido, Gaseoso y Nubes\n Tu respuesta (Inserta el número)--->'))
            if MC4 == 2:
                ciencias.append('1')
                print('Por favor continue con su evaluacion')
            else:
                print('Por favor continue con su evaluacion')
            MC5= int(input('De las siguientes opciones, cuál presenta un cambio físico:\n 1 Botella de vidrio rota \n 2 Fotosíntesis de una Planta \n 3 Digestión \n 4 Metabolismo del Ser Humano\n Tu respuesta (Inserta el número)--->'))
            if MC5 == 1:
                ciencias.append('1')
                print('Por favor continue con su evaluacion')
            else:
                print('Por favor continue con su evaluacion')
            MC6= int(input('De las siguientes opciones, cuál presenta un cambio químico:\n 1 Triturar una hoja de papel \n 2 Tender la cama \n 3 Lavar los trastes \n 4 Fotosíntesis de una Planta\n Tu respuesta (Inserta el número)--->'))
            if MC6 == 4:
                ciencias.append('1')
                print('Por favor continue con su evaluacion')
            else:
                print('Por favor continue con su evaluacion')
            MC7= int(input('¿Cuál es la importancia de la cocción de los alimentos?\n 1 Sus propiedades cambian durante el proceso y son más apetitosos \n 2 Los alimentos cocidos se ven mucho mejor \n 3 Sus propiedades cambian en algunos, no en todos \n Tu respuesta (Inserta el número)--->'))
            if MC7 == 1:
                ciencias.append('1')
                print('Por favor continue con su evaluacion')
            else:
                print('Por favor continue con su evaluacion')
            MC8= int(input('Proceso por el cual se transforman los alimentos, cuando estos se encuentran expuestos a diferentes temperaturas se comienzan a podrir. ¿Cómo se denomina a este proceso?:\n 1 Cocinar \n 2 Descomposición \n 3 Cocción \n 4 Refrigeración\n Tu respuesta (Inserta el número)--->'))
            if MC8 == 2:
                ciencias.append('1')
                print('Por favor continue con su evaluacion')
            else:
                print('Por favor continue con su evaluacion')
            MC9= int(input('Los animales se clasifican en:\n 1 Perro, Gato y Caballo \n 2 Bacterias y Parásitos \n 3 Vertebrados e Invertebrados \n 4 Árboles y Animales\n Tu respuesta (Inserta el número)--->'))
            if MC9 == 3:
                ciencias.append('1')
                print('Por favor continue con su evaluacion')
            else:
                print('Por favor continue con su evaluacion')
            MC10= int(input('¿Cuál es la clasificación de los tipos de animales?\n 1 Mamíferos, Aves, Peces y Perros \n 2 Mamíferos, Aves, Peces, Anfibios y Reptiles \n 3 Anfibios, Peces, Aves y Mascotas \n 4 Mamíferos, Simios, Aves, Anfibios y Reptiles\n Tu respuesta (Inserta el número)--->'))
            if MC10 == 2:
                ciencias.append('1')
                print('Por favor continue con su evaluacion')
            else:
                print('Por favor continue con su evaluacion')          
            print('Tu promedio en ciencias es de ' + str(len(ciencias)))
            promedioC= float(len(ciencias))

            print('*************************************************************')
            PromedioG= (promedioE + promedioM + promedioC) / 3
            print('Tu promedio general es de: ' + str(PromedioG))
        
        datos = []
        datos.append(edad)
        datos.append(promedioE)
        datos.append(promedioM)
        datos.append(promedioC)
        
        print(' ')
        print('El significado o datos de ' + persona + ' es: ')
        print(datos)
        
        registro[persona]= datos
        print('')
        print('Registro de alumnos: ')
        print(registro)
        
        archivo.write('*******************************\n')
        archivo.write('Nombre: ' + persona +' \n')
        archivo.write('Edad: ' + str(edad) + ' \n')
        archivo.write('Promedio Español: ' + str(promedioE) + ' \n')
        archivo.write('Promedio Matematicas: ' + str(promedioM) + ' \n')
        archivo.write('Promedio Ciencias: ' + str(promedioC) + ' \n')
        archivo.write('Promedio General: ' + str(PromedioG) + ' \n')
        
    elif opcion in ['b', 'B']:
        print('El registro es el siguiente')
        print(registro)
        print('¿Que alumno deseas retirar?')
        del registro[input()]
        print('El alumno fue retirado exitosamente')
        print(registro)

    elif opcion in ['c', 'C']:
        print(registro)

    elif opcion in ['d', 'D']:
        print('Fue un placer atenderte')

    else:
        print('Opcion invalida')
        
    seguir = input('Deseas seguir modificando el registro Si/No: ')

print ('Elementos corregidos correctamente')
print ('Bonita tarde')    
        
archivo.close()
